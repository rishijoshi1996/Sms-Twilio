package com.cg;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@SpringBootApplication
public class SmsTwilioApplication implements ApplicationRunner {

	private final static String ACCOUNT_SID = "AC48197e456ae49affd4b465641dd5f398";
	private final static String AUTH_ID = "7b54b3ff28dbd1b7ad539ae69932616d";

	static {
		Twilio.init(ACCOUNT_SID, AUTH_ID);
	}

	public static void main(String[] args) {
		SpringApplication.run(SmsTwilioApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments arg0) throws Exception {
		Message.creator(new PhoneNumber("+917977074267"), new PhoneNumber("+918433869332"),
				"Message from Spring Boot Application").create();
	}
}
