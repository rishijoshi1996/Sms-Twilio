package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;

@Controller
public class GreetingController {

	public static final String ACCOUNT_SID = "AC48197e456ae49affd4b465641dd5f398";
	public static final String AUTH_TOKEN = "7b54b3ff28dbd1b7ad539ae69932616d";
	public static final String TWILIO_NUMBER = "918433869332";

	@RequestMapping("/greeting")
	public String greeting() {
		 sendSMS();
		return "greeting";
	}
	
	public void sendSMS() {
	    try {
	        TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN);

	        // Build a filter for the MessageList
	        List<NameValuePair> params = new ArrayList<NameValuePair>();
	        params.add(new BasicNameValuePair("Body", "Hello, World!"));
	        params.add(new BasicNameValuePair("To", "+917977074267")); //Add real number here
	        params.add(new BasicNameValuePair("From", TWILIO_NUMBER));

	        MessageFactory messageFactory = client.getAccount().getMessageFactory();
	        Message message = messageFactory.create(params);
	        System.out.println(message.getSid());
	    } 
	    catch (TwilioRestException e) {
	        System.out.println(e.getErrorMessage());
	    }
	}
}
